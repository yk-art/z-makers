
(function() {
  // Theme toggle
  const root = document.documentElement;
  const saved = localStorage.getItem('zm-theme');
  if (saved) root.setAttribute('data-theme', saved);
  const toggle = document.getElementById('themeToggle');
  if (toggle) {
    toggle.addEventListener('click', () => {
      const next = root.getAttribute('data-theme') === 'light' ? '' : 'light';
      if (next) root.setAttribute('data-theme', next); else root.removeAttribute('data-theme');
      localStorage.setItem('zm-theme', root.getAttribute('data-theme') || '');
    });
  }

  // Mobile menu
  const menuBtn = document.getElementById('menuToggle');
  const nav = document.getElementById('nav');
  if (menuBtn && nav) {
    menuBtn.addEventListener('click', () => nav.classList.toggle('show'));
  }

  // Back to top
  const btt = document.getElementById('backToTop');
  window.addEventListener('scroll', () => {
    if (window.scrollY > 320) btt.style.display = 'block'; else btt.style.display = 'none';
  });
  btt && btt.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));

  // Scroll reveal
  const observer = new IntersectionObserver(entries => {
    entries.forEach(e => { if (e.isIntersecting) e.target.classList.add('visible'); });
  }, { threshold: 0.12 });
  document.querySelectorAll('.fade-in').forEach(el => observer.observe(el));

  // Animated counters
  const counterEls = document.querySelectorAll('.num');
  let countersStarted = false;
  function startCounters() {
    if (countersStarted) return;
    const rect = document.querySelector('.stats')?.getBoundingClientRect();
    if (!rect) return;
    if (rect.top < window.innerHeight - 80) {
      countersStarted = true;
      counterEls.forEach(el => {
        const target = +el.getAttribute('data-target');
        let cur = 0;
        const step = Math.max(1, Math.floor(target / 120));
        const timer = setInterval(() => {
          cur += step;
          if (cur >= target) { cur = target; clearInterval(timer); }
          el.textContent = cur + (el.dataset.target === '99' ? '%' : '');
        }, 16);
      });
    }
  }
  window.addEventListener('scroll', startCounters);
  startCounters();

  // Particles (simple canvas stars)
  const canvas = document.getElementById('particles');
  if (canvas) {
    const ctx = canvas.getContext('2d');
    let w, h, particles = [];
    function resize() {
      w = canvas.width = canvas.offsetWidth;
      h = canvas.height = canvas.offsetHeight;
      particles = Array.from({length: Math.min(120, Math.floor(w*h/8000))}, () => ({
        x: Math.random()*w,
        y: Math.random()*h,
        r: Math.random()*1.8 + 0.3,
        vx: (Math.random()-0.5)*0.3,
        vy: (Math.random()-0.5)*0.3
      }));
    }
    window.addEventListener('resize', resize); resize();
    function tick() {
      ctx.clearRect(0,0,w,h);
      ctx.fillStyle = 'rgba(255,255,255,0.8)';
      particles.forEach(p => {
        p.x += p.vx; p.y += p.vy;
        if (p.x < 0 || p.x > w) p.vx *= -1;
        if (p.y < 0 || p.y > h) p.vy *= -1;
        ctx.beginPath(); ctx.arc(p.x,p.y,p.r,0,Math.PI*2); ctx.fill();
      });
      requestAnimationFrame(tick);
    }
    tick();
  }
})();
